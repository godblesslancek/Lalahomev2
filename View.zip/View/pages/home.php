
<h1>SmartHouse by TECHOUSE :</h1>
<h2>« Le futur est connecté »</h2>

<div id="acceuil">
    <div class="element1" >
        <h3>NOTRE OFFRE</h3>
        <center><img src="View/Content/images/offre.png" alt="offre" /></center>
        <p>Depuis près de dix ans, TECHOUSE travaille sur un produit révolutionnaire qui a pour but de faciliter l’organisation de chaque foyer : SmartHome. SmartHome vous permet de gérer votre maison à travers diverses fonctionnalités. Peu importe où vous vous situez, vous pouvez, en quelques clics, éteindre la lumière de votre salon, baisser la température de votre chambre, ou encore ouvrir les volets. </p>
    </div>
    <div class="element2" >
        <h3>NOTRE EXPERTISE</h3>
        <center><img src="View/Content/images/expertise.png" alt="expertise" /></center>
        <p>TECHOUSE travaille aux côtés des meilleurs ingénieurs et consultants, afin de vous offrir un produit optimal. Nous accordons beaucoup d’importance à notre savoir-faire, afin de satisfaire au mieux la demande. Nous formons sans cesse nos collaborateurs afin que ceux-ci soient à la pointe des nouveautés technologiques. </p>
    </div>
    <div class="element3" >
        <h3>VOTRE AVIS COMPTE !</h3>
        <center><img src="View/Content/images/avis.png" alt="avis" /></center>
        <p>La satisfaction de nos clients est centrale chez TECHOUSE. Pour l’assurer, nous avons besoin de vous, de vos retours, remarques, et commentaires sur nos produits. N’hésitez pas à nous contacter à la moindre interrogation, notre équipe client est prête à vous répondre. </p>
    </div>
</div>
