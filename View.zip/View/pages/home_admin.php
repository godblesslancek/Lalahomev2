<h1>Bienvenue Mr. WANG !</h1> 
<h2>Administrateur</h2>

<div id="bienvenue">

    <div class="utilisateurs" >
        <h4>Utilisateurs</h4>
        <center><img src="View/Content/images/utilisateurs.png" alt="utilisateurs" /></center>

    <div class="capteur" >
        <h4>Capteurs</h4>
        <center><img src="View/Content/images/capteur.png" alt="offre" /></center>
       
    </div>
    <div class="appartements" >
        <h4>Appartements</h4>
        <center><img src="View/Content/images/appartements.png" alt="piece" /></center>
        
    </div>
    <div class="statistique" >
        <h4>Statistique Global</h4>
        <center><img src="View/Content/images/statistiqueGlobal.png" alt="statistique global" /></center>
        
    </div>
</div>
