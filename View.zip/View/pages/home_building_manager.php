<h1>Bienvenue Mr. WANG !</h1> 
<h2>Gérer mes appartements </h2>

<div id="bienvenue">

    <div class="appartements" >
        <h4>Appartements</h4>
        <center><img src="View/Content/images/appartements.png" alt="piece" /></center>
        
    </div>
    <div class="statistique" >
        <h4>Statistique Global</h4>
        <center><img src="View/Content/images/statistiqueGlobal.png" alt="statistique global" /></center>
        
    </div>
</div>