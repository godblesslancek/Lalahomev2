
<div id="Connexion" >
    <br>
    <center>  <img class="espace" src="View/Content/images/connex.png" alt="espace" />


        <h1>Mon espace</h1>


        <form enctype="multipart/form-data" method="post" accept-charset="UTF-8" action="index.php?controller=user&action=connect">
            <label for="Email">Adresse e-mail :</label>
            <input id="Email" name="Email" type="email">
            <br>
            <label for="Password">Mot de passe</label>
            <input id="Password" name="Password" type="password">
            <br>
            <input id="btn_connexion" value="Connexion" type="submit">
        </form>

    </center>

</div>
